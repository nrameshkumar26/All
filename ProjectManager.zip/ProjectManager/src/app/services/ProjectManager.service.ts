import { Component, NgModule, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


var vURL = "http://localhost:33424/";
//var vURL = "http://localhost:10001/";

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})

export class ProjectManagerService {

  constructor(public http: HttpClient) { }


  getParentTask() {
    //return this.http.get(vURL + "api/TaskManager/GetParentTask");
    return this.http.get(vURL + "api/ProjectManager/Task/Parent");
  }

//

  getProjectDetails() {
    //return this.http.get(vURL + "api/ProjectManager/Project/GetAll");
    return this.http.get(vURL + "api/ProjectManager/Project/All");
  }

  getManagerDetails() {
    //return this.http.get(vURL + "api/ProjectManager/User/GetAll");
    return this.http.get(vURL + "api/ProjectManager/User/All");
  }


  submitProject(project) {
   
    if(project.Project_ID==0){
      //return this.http.post(vURL + "api/ProjectManager/Project/Insert", project, httpOptions);
      return this.http.post(vURL + "api/ProjectManager/Project/AddUpdate", project, httpOptions);
      }
      else
      {
        //return this.http.post(vURL + "api/ProjectManager/Project/Update", project, httpOptions);
        return this.http.post(vURL + "api/ProjectManager/Project/AddUpdate", project, httpOptions);
      }
  }

  SuspendProject(project) {    
    //return this.http.post(vURL + "api/ProjectManager/Project/Update", project, httpOptions);
    return this.http.post(vURL + "api/ProjectManager/Project/Suspend", project, httpOptions);
  }
  // Code for Task screen

  getTaskManager() {
    //return this.http.get(vURL + "api/TaskManager/ViewTask"); ---
    return this.http.get(vURL + "api/ProjectManager/Task/All");
  }

  submitTask(task) {    
    if(task.Task_ID==0){
    //return this.http.post(vURL + "api/TaskManager/AddTask", task, httpOptions);
    return this.http.post(vURL + "api/ProjectManager/Task/AddUpdate", task, httpOptions);
    }
    else{
      //return this.http.post(vURL + "api/TaskManager/EditTask", task, httpOptions);
      return this.http.post(vURL + "api/ProjectManager/Task/AddUpdate", task, httpOptions);
    }
  }

  updateEndTask(task) {
    //return this.http.post(vURL + "api/TaskManager/EditTask", task);
    return this.http.post(vURL + "api/ProjectManager/Task/End", task);
  }

  // Code for User screen 


  getUserDetails() {
    //return this.http.get(vURL + "api/ProjectManager/User/GetAll");
    return this.http.get(vURL + "api/ProjectManager/User/All");
  }

  submitUser(user) {    
    //return this.http.post(vURL + "api/ProjectManager/User/Insert", user, httpOptions);
    return this.http.post(vURL + "api/ProjectManager/User/AddUpdate", user, httpOptions);
  }
  updateUser(user) {
    //return this.http.post(vURL + "api/ProjectManager/User/Update", user, httpOptions);
    return this.http.post(vURL + "api/ProjectManager/User/AddUpdate", user, httpOptions);
  }
  deleteUser(user) {
    //return this.http.post(vURL + "api/ProjectManager/User/Delete", user, httpOptions);
    return this.http.post(vURL + "api/ProjectManager/User/Delete", user, httpOptions);
  }


};
